import { Vector3 } from 'three';

export enum AppState {
  INTRO = 'INTRO',
  MOUSE_MODE = 'MOUSE_MODE',
  GESTURE_MODE = 'GESTURE_MODE',
}

export enum TreeState {
  TREE = 'TREE',
  EXPLODE = 'EXPLODE',
}

export interface ParticleData {
  initialPos: Vector3;
  treePos: Vector3;
  explodePos: Vector3;
  scale: number;
  rotationSpeed: Vector3;
}

export interface GestureResult {
  gesture: 'Closed_Fist' | 'Open_Palm' | 'None';
  handPosition: { x: number; y: number }; // Normalized 0-1
  isDetected: boolean;
}