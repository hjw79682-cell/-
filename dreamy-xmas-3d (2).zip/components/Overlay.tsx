import React, { useState } from 'react';
import { AppState, TreeState } from '../types';

interface OverlayProps {
  appState: AppState;
  treeState: TreeState;
  setAppState: (s: AppState) => void;
  toggleMute: () => void;
  isMuted: boolean;
  handCursor: { x: number; y: number; visible: boolean };
}

const Overlay: React.FC<OverlayProps> = ({ 
  appState, 
  treeState, 
  setAppState, 
  toggleMute, 
  isMuted,
  handCursor
}) => {
  const [hoveredBtn, setHoveredBtn] = useState<string | null>(null);

  if (appState === AppState.INTRO) {
    return (
      <div className="absolute inset-0 flex flex-col items-center justify-center z-50 bg-black/40 backdrop-blur-md">
        <h1 className="font-['Playfair_Display'] text-6xl md:text-8xl text-pink-200 tracking-wider mb-2 drop-shadow-[0_0_15px_rgba(255,105,180,0.8)] italic">
          Dreamy Xmas
        </h1>
        <p className="font-['Inter'] text-pink-100/70 text-sm tracking-[0.3em] mb-12 uppercase">
          Interactive 3D Experience
        </p>

        <div className="flex flex-col gap-4 w-64">
          <button
            onClick={() => setAppState(AppState.MOUSE_MODE)}
            onMouseEnter={() => setHoveredBtn('enter')}
            onMouseLeave={() => setHoveredBtn(null)}
            className={`
              relative px-8 py-4 bg-pink-900/30 border border-pink-400/30 
              text-pink-100 font-['Inter'] tracking-widest text-xs uppercase
              transition-all duration-300 hover:bg-pink-500/20 hover:border-pink-300 hover:shadow-[0_0_20px_rgba(255,105,180,0.4)]
            `}
          >
            Enter Experience
            {hoveredBtn === 'enter' && <div className="absolute inset-0 border border-white/20 animate-ping" />}
          </button>

          <button
            onClick={() => setAppState(AppState.GESTURE_MODE)}
            onMouseEnter={() => setHoveredBtn('gesture')}
            onMouseLeave={() => setHoveredBtn(null)}
            className={`
              relative px-8 py-4 bg-transparent border border-pink-400/20 
              text-pink-200/80 font-['Inter'] tracking-widest text-xs uppercase
              transition-all duration-300 hover:bg-pink-500/10 hover:border-pink-300 hover:text-pink-100
              flex items-center justify-between
            `}
          >
            <span>Gesture Mode</span>
            <span className="text-[10px] bg-pink-500/20 px-1 py-0.5 rounded">BETA</span>
            {hoveredBtn === 'gesture' && <div className="absolute inset-0 border border-white/20 animate-ping" />}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="absolute inset-0 pointer-events-none z-40">
      {/* HUD Header */}
      <div className="absolute top-0 left-0 w-full p-6 flex justify-between items-start">
        <div>
          <h2 className="font-['Playfair_Display'] text-2xl text-pink-200/90 italic">Dreamy Xmas</h2>
          <div className="flex items-center gap-2 mt-1">
             <div className={`w-2 h-2 rounded-full ${treeState === TreeState.TREE ? 'bg-green-400 shadow-[0_0_8px_#4ade80]' : 'bg-red-400 shadow-[0_0_8px_#f87171]'}`} />
             <span className="font-mono text-[10px] text-pink-100/50 uppercase tracking-widest">
               STATUS: {treeState}
             </span>
          </div>
        </div>

        <button 
          onClick={toggleMute}
          className="pointer-events-auto text-pink-200/60 hover:text-pink-100 transition-colors"
        >
          {isMuted ? (
             <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" strokeDasharray="2 2"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2" /></svg>
          ) : (
             <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" /></svg>
          )}
        </button>
      </div>

      {/* Mode Indicator */}
      <div className="absolute bottom-6 left-6 font-mono text-[10px] text-pink-300/40 tracking-widest">
        MODE: {appState === AppState.MOUSE_MODE ? 'MOUSE INTERACTION' : 'AI GESTURE CONTROL'}
        <br />
        {appState === AppState.MOUSE_MODE 
           ? 'CLICK TO INTERACT' 
           : 'PINCH: TREE | OPEN: EXPLODE | MOVE: ROTATE'}
      </div>

      {/* Hand Cursor */}
      {appState === AppState.GESTURE_MODE && handCursor.visible && (
        <div 
          className="absolute w-8 h-8 pointer-events-none transform -translate-x-1/2 -translate-y-1/2 transition-transform duration-75 ease-out"
          style={{ 
            left: `${handCursor.x * 100}%`, 
            top: `${handCursor.y * 100}%` 
          }}
        >
          <div className="absolute inset-0 border border-pink-400 rounded-full animate-ping opacity-50" />
          <div className="absolute inset-2 bg-pink-100 rounded-full shadow-[0_0_15px_#FF69B4]" />
        </div>
      )}
    </div>
  );
};

export default Overlay;