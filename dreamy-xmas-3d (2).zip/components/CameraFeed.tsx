import React, { useEffect, useRef } from 'react';
import { initializeHandLandmarker, detectHands } from '../services/gestureService';
import { GestureResult } from '../types';
import { useFrame } from '@react-three/fiber';

interface CameraFeedProps {
  onGestureDetect: (result: GestureResult) => void;
  isActive: boolean;
}

const CameraFeed: React.FC<CameraFeedProps> = ({ onGestureDetect, isActive }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const lastVideoTimeRef = useRef(-1);

  // Initialize MediaPipe and Camera
  useEffect(() => {
    if (!isActive) return;

    const setupCamera = async () => {
      try {
        await initializeHandLandmarker();
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { width: 320, height: 240, facingMode: 'user' } 
        });
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
        }
      } catch (err) {
        console.error("Camera setup failed", err);
      }
    };

    setupCamera();

    return () => {
      // Cleanup stream
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [isActive]);

  // Frame Loop for Detection (using r3f loop for convenience as it runs on RAF)
  useFrame(() => {
    if (!isActive || !videoRef.current) return;
    
    if (videoRef.current.currentTime !== lastVideoTimeRef.current) {
      lastVideoTimeRef.current = videoRef.current.currentTime;
      
      const results = detectHands(videoRef.current, Date.now());
      
      if (results && results.landmarks.length > 0) {
        const landmarks = results.landmarks[0];
        
        // --- Simple Gesture Recognition Logic ---
        
        // 1. Detect Open Palm vs Closed Fist based on finger tip vs finger pip/mcp distances
        // Tip indices: 4 (Thumb), 8 (Index), 12 (Middle), 16 (Ring), 20 (Pinky)
        // PIP/MCP bases: 2, 5, 9, 13, 17
        
        const isFingerBent = (tipIdx: number, baseIdx: number) => {
           // Distance from wrist(0)
           const wrist = landmarks[0];
           const tip = landmarks[tipIdx];
           const base = landmarks[baseIdx];
           
           const dTip = Math.sqrt(Math.pow(tip.x - wrist.x, 2) + Math.pow(tip.y - wrist.y, 2));
           const dBase = Math.sqrt(Math.pow(base.x - wrist.x, 2) + Math.pow(base.y - wrist.y, 2));
           return dTip < dBase; 
        };

        const indexBent = isFingerBent(8, 5);
        const middleBent = isFingerBent(12, 9);
        const ringBent = isFingerBent(16, 13);
        const pinkyBent = isFingerBent(20, 17);

        let gesture: GestureResult['gesture'] = 'None';
        
        if (indexBent && middleBent && ringBent && pinkyBent) {
          gesture = 'Closed_Fist';
        } else if (!indexBent && !middleBent && !ringBent && !pinkyBent) {
          gesture = 'Open_Palm';
        }

        // Center of palm (approximate using wrist and middle finger mcp)
        const centerX = (landmarks[0].x + landmarks[9].x) / 2;
        const centerY = (landmarks[0].y + landmarks[9].y) / 2;

        onGestureDetect({
          gesture,
          handPosition: { x: centerX, y: centerY },
          isDetected: true
        });

      } else {
        onGestureDetect({
          gesture: 'None',
          handPosition: { x: 0.5, y: 0.5 },
          isDetected: false
        });
      }
    }
  });

  if (!isActive) return null;

  return (
    <div className="absolute bottom-4 right-4 w-40 h-32 border-2 border-pink-500/50 rounded-lg overflow-hidden bg-black/50 backdrop-blur-sm z-50">
       <video 
         ref={videoRef} 
         className="w-full h-full object-cover scale-x-[-1]" 
         playsInline 
         muted 
       />
       <div className="absolute top-1 left-2 text-[10px] text-pink-300 font-mono tracking-widest">
         CAM FEED
       </div>
    </div>
  );
};

export default CameraFeed;