import React, { useMemo, useRef, useLayoutEffect } from 'react';
import { InstancedMesh, Object3D, Vector3, Color, MathUtils, Euler } from 'three';
import { useFrame } from '@react-three/fiber';
import { TreeState } from '../types';
import { LERP_SPEED } from '../constants';

interface TreeParticlesProps {
  count: number;
  color: string;
  shape: 'octahedron' | 'cube' | 'icosahedron' | 'tetrahedron';
  scaleRange: [number, number];
  type: 'leaves' | 'ornaments' | 'ribbon';
  targetState: TreeState;
  emissive?: boolean;
}

const tempObject = new Object3D();
const tempVec3 = new Vector3();

const TreeParticles: React.FC<TreeParticlesProps> = ({ 
  count, 
  color, 
  shape, 
  scaleRange, 
  type,
  targetState,
  emissive = false
}) => {
  const meshRef = useRef<InstancedMesh>(null);
  
  // Pre-calculate positions for both states
  const data = useMemo(() => {
    const positionsTree = new Float32Array(count * 3);
    const positionsExplode = new Float32Array(count * 3);
    const scales = new Float32Array(count);
    const rotations = new Float32Array(count * 3);
    const rotationSpeeds = new Float32Array(count * 3);

    for (let i = 0; i < count; i++) {
      const i3 = i * 3;

      // --- 1. Tree Formation Math ---
      let tx, ty, tz;
      if (type === 'ribbon') {
        // Spiral Ribbon Math
        const t = (i / count) * Math.PI * 6; // 3 full turns
        const height = -10 + (i / count) * 20; // Height from -10 to 10
        const radiusBase = 6 * (1 - (height + 10) / 22); // Tapering radius
        tx = Math.cos(t) * radiusBase;
        tz = Math.sin(t) * radiusBase;
        ty = height;
      } else {
        // Cone Volume / Surface Math
        const height = (Math.random() * 20) - 10; // -10 to 10
        const radiusMax = 7 * (1 - (height + 10) / 22);
        
        let radius, theta;
        if (type === 'ornaments') {
           // Mostly on surface
           radius = radiusMax * (0.8 + Math.random() * 0.3);
           theta = Math.random() * Math.PI * 2;
        } else {
           // Leaves filling volume
           radius = radiusMax * Math.sqrt(Math.random()); // Uniform distribution in circle
           theta = Math.random() * Math.PI * 2;
        }

        tx = radius * Math.cos(theta);
        tz = radius * Math.sin(theta);
        ty = height;
      }

      positionsTree[i3] = tx;
      positionsTree[i3 + 1] = ty;
      positionsTree[i3 + 2] = tz;

      // --- 2. Explode Formation Math ---
      // Random sphere distribution
      const r = 15 + Math.random() * 15;
      const phi = Math.acos(2 * Math.random() - 1);
      const thetaExp = Math.random() * Math.PI * 2;

      positionsExplode[i3] = r * Math.sin(phi) * Math.cos(thetaExp);
      positionsExplode[i3 + 1] = r * Math.sin(phi) * Math.sin(thetaExp);
      positionsExplode[i3 + 2] = r * Math.cos(phi);

      // --- 3. Properties ---
      scales[i] = MathUtils.randFloat(scaleRange[0], scaleRange[1]);
      
      rotations[i3] = Math.random() * Math.PI;
      rotations[i3 + 1] = Math.random() * Math.PI;
      rotations[i3 + 2] = Math.random() * Math.PI;

      rotationSpeeds[i3] = (Math.random() - 0.5) * 0.02;
      rotationSpeeds[i3 + 1] = (Math.random() - 0.5) * 0.02;
      rotationSpeeds[i3 + 2] = (Math.random() - 0.5) * 0.02;
    }

    return { positionsTree, positionsExplode, scales, rotations, rotationSpeeds };
  }, [count, scaleRange, type]);

  // Current positional state (to be interpolated)
  const currentPositions = useRef(new Float32Array(data.positionsTree));

  useFrame(() => {
    if (!meshRef.current) return;

    const targetPositions = targetState === TreeState.TREE ? data.positionsTree : data.positionsExplode;
    
    // Lerp Speed Factor: slower when forming tree for elegance, faster when exploding
    const lerpFactor = targetState === TreeState.EXPLODE ? LERP_SPEED * 1.5 : LERP_SPEED;

    for (let i = 0; i < count; i++) {
      const i3 = i * 3;

      // Lerp position
      currentPositions.current[i3] = MathUtils.lerp(currentPositions.current[i3], targetPositions[i3], lerpFactor);
      currentPositions.current[i3 + 1] = MathUtils.lerp(currentPositions.current[i3 + 1], targetPositions[i3 + 1], lerpFactor);
      currentPositions.current[i3 + 2] = MathUtils.lerp(currentPositions.current[i3 + 2], targetPositions[i3 + 2], lerpFactor);

      // Update dummy object
      tempObject.position.set(
        currentPositions.current[i3],
        currentPositions.current[i3 + 1],
        currentPositions.current[i3 + 2]
      );

      // Apply self-rotation
      data.rotations[i3] += data.rotationSpeeds[i3];
      data.rotations[i3 + 1] += data.rotationSpeeds[i3 + 1];
      data.rotations[i3 + 2] += data.rotationSpeeds[i3 + 2];
      
      tempObject.rotation.set(
        data.rotations[i3],
        data.rotations[i3 + 1],
        data.rotations[i3 + 2]
      );

      tempObject.scale.setScalar(data.scales[i]);
      tempObject.updateMatrix();
      
      meshRef.current.setMatrixAt(i, tempObject.matrix);
    }
    
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  // Geometry selection
  const Geometry = useMemo(() => {
    switch(shape) {
      case 'cube': return <boxGeometry args={[1, 1, 1]} />;
      case 'icosahedron': return <icosahedronGeometry args={[1, 0]} />;
      case 'tetrahedron': return <tetrahedronGeometry args={[1, 0]} />;
      case 'octahedron': return <octahedronGeometry args={[1, 0]} />;
      default: return <sphereGeometry args={[0.5, 8, 8]} />;
    }
  }, [shape]);

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, count]} frustumCulled={false}>
      {Geometry}
      <meshStandardMaterial 
        color={color} 
        roughness={emissive ? 0.1 : 0.4} 
        metalness={emissive ? 0.9 : 0.6}
        emissive={emissive ? color : '#000000'}
        emissiveIntensity={emissive ? 2 : 0}
      />
    </instancedMesh>
  );
};

export default TreeParticles;