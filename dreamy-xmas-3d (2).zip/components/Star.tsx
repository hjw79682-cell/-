import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Mesh, Vector3, MathUtils } from 'three';
import { TreeState } from '../types';
import { COLORS } from '../constants';

interface StarProps {
  treeState: TreeState;
}

const Star: React.FC<StarProps> = ({ treeState }) => {
  const meshRef = useRef<Mesh>(null);
  const glowRef = useRef<Mesh>(null);
  
  // Position targets
  const targetY = treeState === TreeState.TREE ? 10.5 : 20; // Fly away when exploded
  const targetScale = treeState === TreeState.TREE ? 1 : 0.1;
  const currentY = useRef(20);

  useFrame((state) => {
    if (!meshRef.current || !glowRef.current) return;
    
    // Float animation
    const time = state.clock.getElapsedTime();
    const float = Math.sin(time * 2) * 0.2;

    // Lerp Position
    currentY.current = MathUtils.lerp(currentY.current, targetY, 0.05);
    
    meshRef.current.position.set(0, currentY.current + float, 0);
    meshRef.current.rotation.y += 0.01;
    meshRef.current.rotation.z = Math.sin(time) * 0.1;
    
    const scaleLerp = MathUtils.lerp(meshRef.current.scale.x, targetScale, 0.05);
    meshRef.current.scale.setScalar(scaleLerp);

    // Glow pulse
    glowRef.current.position.copy(meshRef.current.position);
    glowRef.current.scale.copy(meshRef.current.scale).multiplyScalar(1.5 + Math.sin(time * 3) * 0.3);
    glowRef.current.rotation.copy(meshRef.current.rotation);
  });

  return (
    <>
      {/* Main Star Body */}
      <mesh ref={meshRef}>
        <dodecahedronGeometry args={[1.2, 0]} />
        <meshStandardMaterial 
          color={COLORS.gold} 
          emissive={COLORS.gold} 
          emissiveIntensity={2}
          roughness={0.1}
          metalness={1}
        />
      </mesh>
      
      {/* Glow Halo */}
      <mesh ref={glowRef}>
        <dodecahedronGeometry args={[1.2, 0]} />
        <meshBasicMaterial 
          color={COLORS.pinkLight} 
          transparent 
          opacity={0.3} 
          wireframe
        />
      </mesh>
    </>
  );
};

export default Star;