import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Environment, ContactShadows, SpotLight } from '@react-three/drei';
import { EffectComposer, Bloom, Vignette } from '@react-three/postprocessing';
import { Group, MathUtils } from 'three';
import TreeParticles from './TreeParticles';
import Star from './Star';
import LightBeam from './LightBeam';
import { TreeState, AppState } from '../types';
import { COLORS, COUNTS, ROTATION_SPEED_AUTO } from '../constants';

interface SceneProps {
  treeState: TreeState;
  appState: AppState;
  rotationVelocity: number;
}

const Scene: React.FC<SceneProps> = ({ treeState, appState, rotationVelocity }) => {
  const groupRef = useRef<Group>(null);
  
  useFrame((state, delta) => {
    if (groupRef.current) {
      // Base auto rotation + hand gesture added velocity
      const rotationSpeed = (ROTATION_SPEED_AUTO * delta) + (rotationVelocity * delta);
      groupRef.current.rotation.y += rotationSpeed;
    }
  });

  return (
    <>
      <color attach="background" args={[COLORS.bg]} />
      
      {/* Lighting */}
      <ambientLight intensity={0.2} color={COLORS.pinkDeep} />
      <SpotLight
        position={[10, 20, 10]}
        angle={0.3}
        penumbra={1}
        intensity={200}
        color={COLORS.pinkLight}
        castShadow
      />
      <pointLight position={[-10, -5, -10]} intensity={50} color={COLORS.purpleGem} />
      <Environment preset="city" />

      {/* Main Rotating Group */}
      <group ref={groupRef}>
        {/* 1. Leaves - Pink Octahedrons */}
        <TreeParticles
          count={COUNTS.leaves}
          color={COLORS.pinkDeep}
          shape="octahedron"
          scaleRange={[0.15, 0.4]}
          type="leaves"
          targetState={treeState}
        />

        {/* 2. Ornaments - Shiny Cubes & Icosahedrons */}
        <TreeParticles
          count={COUNTS.ornaments / 2}
          color={COLORS.white}
          shape="cube"
          scaleRange={[0.3, 0.6]}
          type="ornaments"
          targetState={treeState}
          emissive
        />
        <TreeParticles
          count={COUNTS.ornaments / 2}
          color={COLORS.purpleGem}
          shape="icosahedron"
          scaleRange={[0.2, 0.5]}
          type="ornaments"
          targetState={treeState}
        />

        {/* 3. Ribbon - White Tetrahedrons */}
        <TreeParticles
          count={COUNTS.ribbon}
          color={COLORS.white}
          shape="tetrahedron"
          scaleRange={[0.05, 0.15]}
          type="ribbon"
          targetState={treeState}
          emissive
        />

        {/* 4. The Star */}
        <Star treeState={treeState} />

        {/* 5. Glowing Light Beam Ribbon */}
        <LightBeam treeState={treeState} />
      </group>

      {/* Shadows */}
      <ContactShadows 
        opacity={0.5} 
        scale={40} 
        blur={2} 
        far={10} 
        resolution={256} 
        color="#000000" 
      />

      {/* Post Processing */}
      <EffectComposer disableNormalPass>
        <Bloom 
          luminanceThreshold={0.8} 
          mipBlur 
          intensity={1.5} 
          radius={0.6}
        />
        <Vignette eskil={false} offset={0.1} darkness={0.6} />
      </EffectComposer>
    </>
  );
};

export default Scene;