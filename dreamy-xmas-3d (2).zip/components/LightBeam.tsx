import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { CatmullRomCurve3, Vector3, Mesh, Color, DoubleSide, AdditiveBlending, ShaderMaterial } from 'three';
import { TreeState } from '../types';
import { COLORS } from '../constants';
import * as THREE from 'three';

interface LightBeamProps {
  treeState: TreeState;
}

const LightBeam: React.FC<LightBeamProps> = ({ treeState }) => {
  const meshRef = useRef<Mesh>(null);
  const materialRef = useRef<ShaderMaterial>(null);

  const curve = useMemo(() => {
    const points: Vector3[] = [];
    const turns = 4.5;
    const heightStart = -11;
    const heightEnd = 11;
    const heightRange = heightEnd - heightStart;
    
    const count = 150;
    for (let i = 0; i <= count; i++) {
      const t = i / count;
      // Spiral math
      const angle = t * Math.PI * 2 * turns;
      const y = heightStart + t * heightRange;
      
      // Radius tapers as we go up
      // Base radius ~9 at bottom, ~0.5 at top (slightly wider than tree)
      const radius = 9 * (1 - t) + 0.5;
      
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius;
      points.push(new Vector3(x, y, z));
    }
    return new CatmullRomCurve3(points);
  }, []);

  // Shader definition for glowing beam
  const shaderArgs = useMemo(() => {
    // Boost color for bloom effect
    const color = new Color(COLORS.pinkLight).multiplyScalar(2.5); 
    
    return {
      uniforms: {
        uTime: { value: 0 },
        uColor: { value: color },
        uOpacity: { value: 0.0 }
      },
      vertexShader: `
        varying vec2 vUv;
        void main() {
          vUv = uv;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform float uTime;
        uniform vec3 uColor;
        uniform float uOpacity;
        varying vec2 vUv;
        
        void main() {
          // Flowing energy effect along the tube
          // vUv.x is along the tube, vUv.y is around the circumference
          
          float flow = sin(vUv.x * 20.0 - uTime * 5.0) * 0.5 + 0.5;
          float pulse = sin(uTime * 2.0) * 0.2 + 0.8;
          
          // Soften edges along the width of the ribbon
          float edge = smoothstep(0.0, 0.3, vUv.y) * (1.0 - smoothstep(0.7, 1.0, vUv.y));
          
          // Composition
          vec3 finalColor = uColor * (0.5 + flow * 0.5) * pulse;
          float alpha = uOpacity * edge;
          
          gl_FragColor = vec4(finalColor, alpha);
        }
      `,
      transparent: true,
      side: DoubleSide,
      blending: AdditiveBlending,
      depthWrite: false,
    };
  }, []);

  useFrame((state, delta) => {
    if (meshRef.current) {
      // Scale animation based on state
      const targetScale = treeState === TreeState.TREE ? 1 : 1.8;
      meshRef.current.scale.lerp(new Vector3(targetScale, targetScale, targetScale), delta * 1.5);
      
      // Gentle floating rotation
      meshRef.current.rotation.y -= delta * 0.2;
    }

    if (materialRef.current) {
      materialRef.current.uniforms.uTime.value = state.clock.elapsedTime;
      
      // Fade out in explode state to avoid visual clutter
      const targetOpacity = treeState === TreeState.TREE ? 0.6 : 0.1;
      materialRef.current.uniforms.uOpacity.value = THREE.MathUtils.lerp(
        materialRef.current.uniforms.uOpacity.value,
        targetOpacity,
        delta * 2.0
      );
    }
  });

  return (
    <mesh ref={meshRef}>
      {/* Tube args: curve, segments, radius, radialSegments, closed */}
      <tubeGeometry args={[curve, 256, 0.15, 8, false]} />
      <shaderMaterial ref={materialRef} args={[shaderArgs]} />
    </mesh>
  );
};

export default LightBeam;