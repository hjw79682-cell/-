export const COLORS = {
  bg: '#050103',
  pinkLight: '#FFB7C5',
  pinkDeep: '#FF69B4',
  purpleGem: '#E6E6FA',
  white: '#FFFFFF',
  gold: '#FFD700',
};

export const COUNTS = {
  leaves: 5000,
  ornaments: 500,
  ribbon: 1500,
  sparkles: 100,
};

// Physics / Animation
export const LERP_SPEED = 0.05;
export const ROTATION_SPEED_AUTO = 0.1;
export const ROTATION_SENSITIVITY_HAND = 2.5;

// Audio
export const BG_MUSIC_URL = 'https://cdn.pixabay.com/download/audio/2022/11/22/audio_febc508520.mp3?filename=christmas-magic-127278.mp3'; // Royalty free placeholder