import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Canvas } from '@react-three/fiber';
import Scene from './components/Scene';
import Overlay from './components/Overlay';
import CameraFeed from './components/CameraFeed';
import { AppState, TreeState, GestureResult } from './types';
import { BG_MUSIC_URL, ROTATION_SENSITIVITY_HAND } from './constants';
import { MathUtils } from 'three';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.INTRO);
  const [treeState, setTreeState] = useState<TreeState>(TreeState.TREE);
  const [rotationVelocity, setRotationVelocity] = useState(0);
  const [handCursor, setHandCursor] = useState({ x: 0.5, y: 0.5, visible: false });
  const [isMuted, setIsMuted] = useState(false);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const lastHandX = useRef(0.5);

  // Audio Init
  useEffect(() => {
    audioRef.current = new Audio(BG_MUSIC_URL);
    audioRef.current.loop = true;
    audioRef.current.volume = 0.5;
    
    return () => {
      audioRef.current?.pause();
    };
  }, []);

  // Handle Mode Change (Play Audio)
  useEffect(() => {
    if (appState !== AppState.INTRO && audioRef.current) {
      if (!isMuted) {
          audioRef.current.play().catch(e => console.warn("Audio autoplay blocked", e));
      }
    }
  }, [appState, isMuted]);

  const toggleMute = () => {
    setIsMuted(prev => {
      const next = !prev;
      if (audioRef.current) {
        if (next) audioRef.current.pause();
        else audioRef.current.play();
      }
      return next;
    });
  };

  // Mouse Interaction
  const handleCanvasClick = () => {
    if (appState === AppState.MOUSE_MODE) {
      setTreeState(prev => prev === TreeState.TREE ? TreeState.EXPLODE : TreeState.TREE);
    }
  };

  // Gesture Interaction
  const handleGestureDetect = useCallback((result: GestureResult) => {
    if (appState !== AppState.GESTURE_MODE) return;

    // 1. Update Cursor (Mirror X)
    if (result.isDetected) {
      // Smooth cursor
      setHandCursor(prev => ({
        x: MathUtils.lerp(prev.x, 1 - result.handPosition.x, 0.2), // Mirror horizontal
        y: MathUtils.lerp(prev.y, result.handPosition.y, 0.2),
        visible: true
      }));

      // 2. Gesture State Logic
      if (result.gesture === 'Closed_Fist') {
        setTreeState(TreeState.TREE);
      } else if (result.gesture === 'Open_Palm') {
        setTreeState(TreeState.EXPLODE);
      }

      // 3. Rotation Logic (Delta X)
      const currentMirroredX = 1 - result.handPosition.x;
      const deltaX = currentMirroredX - lastHandX.current;
      
      // If moving significantly and hand is open (drag rotate)
      if (Math.abs(deltaX) > 0.001 && result.gesture === 'Open_Palm') {
         setRotationVelocity(deltaX * ROTATION_SENSITIVITY_HAND * 100);
      } else {
         // Decay velocity
         setRotationVelocity(v => MathUtils.lerp(v, 0, 0.1));
      }
      
      lastHandX.current = currentMirroredX;

    } else {
      setHandCursor(prev => ({ ...prev, visible: false }));
      setRotationVelocity(v => MathUtils.lerp(v, 0, 0.1));
    }
  }, [appState]);

  return (
    <div className="relative w-full h-screen bg-[#050103] overflow-hidden">
      
      {/* 3D Canvas - Always Rendered but hidden in intro if needed (though nice to show background) */}
      <Canvas
        camera={{ position: [0, 0, 25], fov: 45 }}
        dpr={[1, 2]} // Optimization for HiDPI
        onClick={handleCanvasClick}
        shadows
      >
        {/* Pass camera feed hook inside Canvas to access useFrame */}
        <CameraFeed 
            isActive={appState === AppState.GESTURE_MODE} 
            onGestureDetect={handleGestureDetect} 
        />
        
        <Scene 
          treeState={treeState} 
          appState={appState}
          rotationVelocity={rotationVelocity}
        />
      </Canvas>

      {/* UI Layer */}
      <Overlay 
        appState={appState}
        treeState={treeState}
        setAppState={setAppState}
        toggleMute={toggleMute}
        isMuted={isMuted}
        handCursor={handCursor}
      />
    </div>
  );
};

export default App;